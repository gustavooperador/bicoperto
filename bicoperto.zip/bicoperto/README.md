# 🔎 BicoPerto

Protótipo de site para encontrar oportunidades de bicos perto de você.

## O que tem no projeto

| Arquivo | Para que serve |
|---|---|
| `app.py` | Site em Python (Gradio): criar conta, entrar, oportunidades, registro, publicar, relatório e perfil |
| `banco.py` + `schema.sql` | Banco de dados SQLite (usuários, habilidades, oportunidades, interesses) |
| `termos_de_uso.md` | Termos de Uso que a pessoa precisa aceitar para criar a conta |
| `docs/index.html` | Protótipo que roda direto no navegador (sem instalar nada) |
| `docs/termos_de_uso.html` | Página com os Termos de Uso, que tem link próprio |
| `exemplos/relatorio_exemplo.csv` | Exemplo de relatório para testar a importação |

## Rodar o site em Python

```bash
pip install -r requirements.txt
python app.py
```

No Google Colab: envie a pasta, rode `!pip install gradio -q` e depois `%run app.py`.
O banco `bicoperto.db` é criado sozinho na primeira vez.

## Relatório CSV

Na aba **Relatório** você gera o arquivo (separador `;`, abre direto no Excel) e também
importa um CSV para ver o conteúdo em uma tabela.

## Termos de Uso

- Na criação da conta, a pessoa só consegue continuar se marcar **Li e aceito os Termos de Uso**.
- O banco guarda a data e a versão dos termos aceitos (`aceitou_termos_em`, `versao_termos`).
- O link dos termos no protótipo web é `docs/index.html#termos` ou `docs/termos_de_uso.html`.

## Ver o protótipo no navegador pelo GitHub Pages

1. No repositório, abra **Settings → Pages**.
2. Em **Source**, escolha **Deploy from a branch**, branch `main` e pasta `/docs`.
3. Depois de alguns minutos o site fica em `https://SEU-USUARIO.github.io/bicoperto/`
   e os termos em `https://SEU-USUARIO.github.io/bicoperto/termos_de_uso.html`.

> No protótipo web os dados ficam salvos no próprio navegador (localStorage). O banco SQLite é usado pela versão em Python.
> Os Termos de Uso são um modelo para o projeto acadêmico; peça revisão de um profissional de direito antes de usar com o público.
