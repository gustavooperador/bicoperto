-- Banco de dados do BicoPerto (SQLite)

CREATE TABLE IF NOT EXISTS usuarios (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    nome               TEXT NOT NULL,
    nascimento         TEXT NOT NULL,              -- dd/mm/aaaa
    email              TEXT NOT NULL UNIQUE,
    senha_hash         TEXT NOT NULL,              -- salt$hash (PBKDF2), nunca a senha pura
    endereco           TEXT NOT NULL,
    bairro             TEXT NOT NULL DEFAULT '',
    cidade             TEXT NOT NULL DEFAULT '',
    aceitou_termos_em  TEXT NOT NULL,              -- data e hora do aceite (ISO 8601)
    versao_termos      TEXT NOT NULL,              -- versão dos termos aceita
    criado_em          TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS habilidades (
    usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    habilidade  TEXT NOT NULL,
    PRIMARY KEY (usuario_id, habilidade)
);

CREATE TABLE IF NOT EXISTS oportunidades (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo       TEXT NOT NULL UNIQUE,
    valor        TEXT NOT NULL,
    local        TEXT NOT NULL DEFAULT '',
    data         TEXT NOT NULL DEFAULT '',
    contratante  TEXT NOT NULL,
    descricao    TEXT NOT NULL DEFAULT '',
    dono_id      INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,   -- NULL = oportunidade de exemplo
    criado_em    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS interesses (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id       INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    oportunidade_id  INTEGER NOT NULL REFERENCES oportunidades(id) ON DELETE CASCADE,
    criado_em        TEXT NOT NULL,
    UNIQUE (usuario_id, oportunidade_id)
);
