# Termos de Uso do BicoPerto

Versão 1.0 · em vigor desde 24/11/2026

## 1. Aceitação dos termos

Ao criar uma conta no BicoPerto você declara que leu, entendeu e concorda com estes Termos de Uso. Se não concordar, não crie a conta nem use o site.

## 2. O que é o BicoPerto

O BicoPerto é uma plataforma que aproxima pessoas que precisam de um serviço pontual (contratantes) de pessoas que querem fazer esse serviço (prestadores). O BicoPerto apenas divulga as oportunidades e registra o interesse dos usuários. Ele não é parte do acordo entre contratante e prestador e não cria vínculo de emprego, sociedade ou representação entre eles.

## 3. Cadastro

Para criar a conta é preciso ter 18 anos ou mais e informar dados verdadeiros: nome, data de nascimento, e-mail, endereço e senha. Você é responsável por manter a senha em segredo e por tudo o que for feito com a sua conta.

## 4. Publicação de oportunidades

Quem publica uma oportunidade deve descrever o serviço, o valor, o local e a data de forma correta e honesta. É proibido publicar ofertas falsas, ilegais, perigosas ou que ofendam outras pessoas. O BicoPerto pode remover qualquer publicação que descumpra estes termos.

## 5. Combinados e pagamentos

Valor, forma de pagamento, horário e condições do serviço são combinados diretamente entre contratante e prestador. O BicoPerto não recebe, guarda nem garante pagamentos. Antes de ir a um local desconhecido, avise alguém de confiança e confirme os detalhes do serviço.

## 6. Dados pessoais (LGPD)

Os dados informados no cadastro são usados para criar e manter a sua conta, mostrar o seu perfil, registrar os seus interesses em oportunidades e gerar relatórios do site. Tratamos esses dados conforme a Lei Geral de Proteção de Dados (Lei 13.709/2018). Você pode pedir a correção ou a exclusão dos seus dados a qualquer momento pelo contato indicado no site. Registramos também a data e a versão dos termos que você aceitou.

## 7. Condutas proibidas

Não é permitido usar o BicoPerto para fraudar, assediar, discriminar, enviar spam, coletar dados de outros usuários ou tentar invadir ou prejudicar o funcionamento do site.

## 8. Limitação de responsabilidade

O BicoPerto é oferecido como um protótipo, no estado em que se encontra, e pode ficar indisponível ou mudar sem aviso. O BicoPerto não se responsabiliza por danos decorrentes dos serviços combinados entre usuários, nos limites permitidos em lei.

## 9. Alterações dos termos

Estes termos podem ser atualizados. Quando houver mudança relevante, pediremos um novo aceite.

## 10. Foro

Aplica-se a lei brasileira. Eventuais conflitos serão resolvidos no foro do domicílio do usuário, conforme o Código de Defesa do Consumidor.

> Modelo de termos feito para um projeto acadêmico. Antes de usar o site com o público de verdade, peça a revisão de um profissional de direito.
