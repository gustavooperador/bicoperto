# BicoPerto - versão Gradio com banco de dados SQLite
# Como rodar:   pip install -r requirements.txt   e depois   python app.py
# No Google Colab:   %run app.py

import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

import gradio as gr

import banco

banco.criar_banco()

TERMOS = (Path(__file__).parent / "termos_de_uso.md").read_text(encoding="utf-8")

HABILIDADES = [
    "Pintura", "Limpeza", "Mudança", "Jardinagem",
    "Reparos", "Montagem de móveis", "Cozinha", "Cuidados com pets"
]

# ==========================
# DATAS E IDADE
# ==========================

def hoje():
    return datetime.now(timezone(timedelta(hours=-3))).date()   # horário de Brasília

def ler_data(texto):
    # transforma "25/12/2000" em uma data; se estiver errada, devolve None
    try:
        data = datetime.strptime(texto.strip(), "%d/%m/%Y").date()
    except ValueError:
        return None
    if data.year < 1900 or data > hoje():
        return None
    return data

def calcular_idade(nascimento):
    h = hoje()
    # tira 1 se a pessoa ainda não fez aniversário este ano
    return h.year - nascimento.year - ((h.month, h.day) < (nascimento.month, nascimento.day))

def mostrar_idade(texto):
    nascimento = ler_data(texto)
    if not nascimento:
        return ""
    return f"{calcular_idade(nascimento)} anos"

# ==========================
# NAVEGAÇÃO ENTRE TELAS
# ==========================
# Cada "tela" é uma coluna. Só uma fica visível por vez.
# Ordem: criar conta -> (termos) -> entrar -> app

def mostrar(tela):
    return (
        gr.update(visible=(tela == "cadastro")),
        gr.update(visible=(tela == "login")),
        gr.update(visible=(tela == "app")),
        gr.update(visible=(tela == "termos")),
    )

def ir_para_cadastro():
    return mostrar("cadastro")

def ir_para_login():
    return mostrar("login")

def ir_para_termos():
    return mostrar("termos")

# ==========================
# FUNÇÕES: CONTA
# ==========================

def cadastrar(nome, nascimento, email, senha, endereco, bairro, cidade, habilidades, aceitou):
    nome, email = nome.strip(), email.strip().lower()

    if not nome or not nascimento.strip() or not email or not senha or not endereco.strip():
        return (*mostrar("cadastro"), "❌ Preencha nome, data de nascimento, e-mail, senha e endereço.", gr.update())

    data = ler_data(nascimento)
    if not data:
        return (*mostrar("cadastro"), "❌ Data de nascimento inválida. Use o formato dd/mm/aaaa.", gr.update())

    if calcular_idade(data) < 18:
        return (*mostrar("cadastro"), "❌ Para criar conta é preciso ter 18 anos ou mais.", gr.update())

    if "@" not in email:
        return (*mostrar("cadastro"), "❌ E-mail inválido.", gr.update())

    if not aceitou:
        return (*mostrar("cadastro"), "❌ Para criar a conta, marque que leu e aceita os Termos de Uso.", gr.update())

    criou = banco.criar_usuario(
        nome, nascimento.strip(), email, senha,
        endereco.strip(), bairro.strip(), cidade.strip(), habilidades,
    )
    if not criou:
        return (*mostrar("cadastro"), "❌ Esse e-mail já tem conta. Volte e entre.", gr.update())

    gr.Info("✅ Conta criada! Agora é só entrar.")

    # Deu certo: vai para o login, com o e-mail já preenchido
    return (*mostrar("login"), "", gr.update(value=email))


def login(email, senha):
    email = email.strip().lower()
    conta = banco.verificar_login(email, senha)

    if not conta:
        return (*mostrar("login"), "❌ E-mail ou senha incorretos.", None, "")

    # Deu certo: vai para o app. Guardamos só o e-mail de quem entrou.
    return (*mostrar("app"), "", email, f"### 👋 Olá, {conta['nome']}!")


def sair():
    return (*mostrar("login"), None, "")

# ==========================
# FUNÇÕES: OPORTUNIDADES
# ==========================

def detalhes(vaga):
    if not vaga:
        return "Escolha uma oportunidade na lista acima 👆"

    d = banco.obter_oportunidade(vaga)

    return f"""
### 📌 {vaga}

💰 **Valor:** {d['valor']}

📍 **Local:** {d['local']}

📅 **Data:** {d['data']}

👤 **Contratante:** {d['contratante']}

📝 **Descrição:** {d['descricao']}
"""


def registro(usuario):
    itens = banco.listar_interesses(usuario) if usuario else []

    if not itens:
        return "Você ainda não enviou interesse em nenhuma oportunidade. 🙂"

    texto = f"### 📋 Você enviou interesse em {len(itens)} oportunidade(s)\n"

    for item in itens:   # a mais nova aparece primeiro
        hora = datetime.fromisoformat(item["hora"]).strftime("%d/%m às %H:%M")
        texto += f"""
---
**📌 {item['titulo']}**

💰 {item['valor']} &nbsp;|&nbsp; 📅 {item['data']} &nbsp;|&nbsp; 📍 {item['local']}

👤 Contratante: {item['contratante']}

✅ Interesse enviado em {hora}
"""
    return texto


def interesse(vaga, usuario):
    if not vaga:
        gr.Warning("Escolha uma oportunidade primeiro.")
        return gr.update()

    if banco.registrar_interesse(usuario, vaga):
        gr.Info(f"✅ Interesse enviado para: {vaga}")
    else:
        gr.Info("Você já enviou interesse nessa oportunidade.")
    return registro(usuario)


def ir_para_registro():
    return gr.Tabs(selected="aba_registro")


def publicar(titulo, valor, local, data, descricao, usuario):
    if not titulo.strip() or not valor.strip():
        gr.Warning("Preencha pelo menos o título e o valor.")
        return (gr.update(),) * 7

    if not banco.criar_oportunidade(titulo.strip(), valor.strip(), local.strip(),
                                    data.strip(), descricao.strip(), usuario):
        gr.Warning("Já existe uma oportunidade com esse título. Use outro título.")
        return (gr.update(),) * 7

    gr.Info("✅ Oportunidade publicada!")

    return (
        gr.update(choices=banco.listar_titulos(), value=titulo.strip()),   # atualiza a lista
        "", "", "", "", "",                                                # limpa os campos
        gr.Tabs(selected="aba_oportunidades"),                             # volta para Oportunidades
    )

# ==========================
# FUNÇÕES: PERFIL
# ==========================

def perfil(usuario):
    conta = banco.obter_usuario(usuario) if usuario else None

    if not conta:
        return ""

    nascimento = ler_data(conta["nascimento"])
    idade = f"{calcular_idade(nascimento)} anos" if nascimento else "—"

    partes = [conta["endereco"], conta["bairro"], conta["cidade"]]
    endereco = ", ".join(p for p in partes if p) or "—"
    habilidades = ", ".join(conta["habilidades"]) or "—"
    aceite = datetime.fromisoformat(conta["aceitou_termos_em"]).strftime("%d/%m/%Y às %H:%M")

    return f"""
### 👤 {conta['nome']}

🎂 **Nascimento:** {conta['nascimento']} ({idade})

📧 **E-mail:** {conta['email']}

📍 **Endereço:** {endereco}

🛠️ **O que sabe fazer:** {habilidades}

---

📢 **Oportunidades publicadas:** {banco.contar_publicadas(usuario)}

🙋 **Interesses enviados:** {len(banco.listar_interesses(usuario))}

📄 **Termos de Uso aceitos:** versão {conta['versao_termos']}, em {aceite}
"""

# ==========================
# FUNÇÕES: RELATÓRIO CSV
# ==========================

def gerar_relatorio():
    caminho = banco.gerar_relatorio_csv()
    gr.Info("✅ Relatório gerado! Clique no arquivo para baixar.")
    return caminho


def importar_relatorio(arquivo):
    if not arquivo:
        return gr.update(value=None), "Escolha um arquivo .csv para ver o conteúdo."

    try:
        cabecalho, linhas = banco.ler_relatorio_csv(arquivo)
    except (UnicodeDecodeError, OSError):
        return gr.update(value=None), "❌ Não consegui ler esse arquivo. Envie um relatório .csv do BicoPerto."

    if not cabecalho:
        return gr.update(value=None), "❌ O arquivo está vazio."

    # completa linhas curtas para a tabela não quebrar
    linhas = [l + [""] * (len(cabecalho) - len(l)) for l in linhas]
    tabela = {"headers": cabecalho, "data": linhas}
    return tabela, f"✅ Relatório importado: {len(linhas)} linha(s) e {len(cabecalho)} coluna(s)."

# ==========================
# VISUAL (fundo azul claro + caixas brancas)
# ==========================

CSS = """
<style>

/* Força o visual claro, mesmo se o navegador estiver no modo escuro */
.gradio-container, .dark .gradio-container, body.dark .gradio-container{
    --body-background-fill: transparent;
    --background-fill-primary: #ffffff;
    --background-fill-secondary: #f0f7ff;
    --block-background-fill: #ffffff;
    --panel-background-fill: #ffffff;
    --input-background-fill: #ffffff;
    --input-background-fill-focus: #ffffff;
    --input-background-fill-hover: #ffffff;
    --block-label-background-fill: #ffffff;
    --block-label-text-color: #1e3a8a;
    --block-title-text-color: #1e3a8a;
    --body-text-color: #1e3a8a;
    --body-text-color-subdued: #475f9e;
    --input-placeholder-color: #8aa0cf;
    --input-border-color: #bfdbfe;
    --block-border-color: #bfdbfe;
    --border-color-primary: #bfdbfe;
    --checkbox-label-background-fill: #ffffff;
    --checkbox-label-background-fill-hover: #eff6ff;
    --checkbox-label-background-fill-selected: #dbeafe;
    --checkbox-label-text-color: #1e3a8a;
    --checkbox-label-text-color-selected: #1e3a8a;
    --checkbox-background-color: #ffffff;
    --color-accent: #2563eb;
    color-scheme: light;
}

/* fundo azul claro da página */
.gradio-container{
    background: linear-gradient(160deg, #e0f2fe 0%, #bfdbfe 100%) !important;
}

/* textos em azul escuro (aparecem bem no branco e no azul claro) */
.gradio-container h1, .gradio-container h2, .gradio-container h3,
.gradio-container p, .gradio-container label span,
.gradio-container .prose, .gradio-container .prose *{
    color: #1e3a8a !important;
}

/* caixas de digitar: fundo branco, letra azul escura */
.gradio-container input, .gradio-container textarea, .gradio-container select{
    background: #ffffff !important;
    color: #1e3a8a !important;
    border: 1px solid #bfdbfe !important;
}

/* legenda dentro da caixa (ex.: "Nome"): fundo branco, letra azul escura */
.gradio-container span[data-testid="block-info"]{
    background: #ffffff !important;
    color: #1e3a8a !important;
}

/* lista que abre no Dropdown */
.gradio-container ul.options{
    background: #ffffff !important;
}
.gradio-container ul.options li{
    color: #1e3a8a !important;
}
.gradio-container ul.options li:hover,
.gradio-container ul.options li.selected{
    background: #dbeafe !important;
}

/* abas */
.gradio-container button[role="tab"]{
    color: #1e3a8a !important;
    background: transparent !important;
}
.gradio-container button[role="tab"][aria-selected="true"]{
    border-bottom: 3px solid #2563eb !important;
    font-weight: 600;
}

/* botões */
.gradio-container button.primary{
    background: #2563eb !important;
    color: #ffffff !important;
    border: none !important;
    transition: transform 0.15s ease;
}
.gradio-container button.primary:hover{
    transform: scale(1.03);
}
.gradio-container button.secondary{
    background: #ffffff !important;
    color: #1e40af !important;
    border: 1px solid #93c5fd !important;
}

/* título do topo sem caixa */
.cab{
    background: transparent !important;
    border: none !important;
    box-shadow: none !important;
}

/* cada tela vira um "cartão" que aparece suavemente */
.cartao{
    background: #ffffff !important;
    border-radius: 20px !important;
    padding: 24px !important;
    box-shadow: 0 8px 24px rgba(30, 64, 175, 0.15) !important;
    animation: aparecer 0.45s ease;
}

@keyframes aparecer{
    from{ opacity: 0; transform: translateY(14px); }
    to{ opacity: 1; transform: translateY(0); }
}
</style>
"""

# ==========================
# INTERFACE
# ==========================

with gr.Blocks(title="BicoPerto") as app:

    gr.HTML(CSS)

    usuario = gr.State(None)   # guarda o e-mail de quem está logado

    gr.Markdown("# 🔎 BicoPerto\nEncontre oportunidades perto de você", elem_classes="cab")

    # -------- TELA 1: CRIAR CONTA (já com o cadastro do perfil) --------
    with gr.Column(visible=False, elem_classes="cartao") as tela_cadastro:
        gr.Markdown("## ✨ Criar conta")

        with gr.Row():
            nome_cad = gr.Textbox(label="Nome completo")
            email_cad = gr.Textbox(label="E-mail")

        with gr.Row():
            nasc_cad = gr.Textbox(label="Data de nascimento", placeholder="dd/mm/aaaa")
            idade_cad = gr.Textbox(
                label="Idade (calculada pela data)",
                interactive=False
            )

        senha_cad = gr.Textbox(label="Senha", type="password")

        endereco_cad = gr.Textbox(label="Endereço (rua e número)")
        with gr.Row():
            bairro_cad = gr.Textbox(label="Bairro")
            cidade_cad = gr.Textbox(label="Cidade")

        habilidades_cad = gr.CheckboxGroup(
            choices=HABILIDADES,
            label="O que você faz / sabe fazer?"
        )

        aceite_cad = gr.Checkbox(label="Li e aceito os Termos de Uso")
        btn_ler_termos = gr.Button("📄 Ler os Termos de Uso")

        msg_cad = gr.Markdown()
        btn_cadastro = gr.Button("Criar conta", variant="primary")
        btn_ja_tenho = gr.Button("Já tenho conta")

    # -------- TELA 2: ENTRAR --------
    with gr.Column(visible=True, elem_classes="cartao") as tela_login:
        gr.Markdown("## 🔐 Entrar")
        email_login = gr.Textbox(label="E-mail")
        senha_login = gr.Textbox(label="Senha", type="password")
        msg_login = gr.Markdown()
        btn_login = gr.Button("Entrar", variant="primary")
        btn_criar = gr.Button("Criar uma conta")

    # -------- TELA 3: APP (com abas) --------
    with gr.Column(visible=False, elem_classes="cartao") as tela_app:

        saudacao = gr.Markdown()

        with gr.Tabs() as abas:

            with gr.Tab("Oportunidades", id="aba_oportunidades"):
                vaga = gr.Dropdown(
                    choices=banco.listar_titulos(),
                    label="Escolha uma oportunidade"
                )
                detalhes_box = gr.Markdown("Escolha uma oportunidade na lista acima 👆")
                btn_interesse = gr.Button("Tenho interesse", variant="primary")
                btn_ver_registro = gr.Button("Ver meu registro →")

            with gr.Tab("Registro", id="aba_registro") as aba_registro:
                registro_box = gr.Markdown(
                    "Você ainda não enviou interesse em nenhuma oportunidade. 🙂"
                )

            with gr.Tab("Publicar", id="aba_publicar"):
                titulo = gr.Textbox(label="Título")
                valor = gr.Textbox(label="Valor (ex.: R$ 100)")
                local = gr.Textbox(label="Localização")
                data = gr.Textbox(label="Data")
                descricao = gr.Textbox(label="Descrição", lines=3)
                btn_publicar = gr.Button("Publicar oportunidade", variant="primary")

            with gr.Tab("Relatório", id="aba_relatorio"):
                gr.Markdown("### 📊 Baixar relatório\nGera um arquivo CSV com todas as oportunidades e quantos interesses cada uma recebeu.")
                btn_gerar = gr.Button("Gerar relatório CSV", variant="primary")
                arquivo_rel = gr.File(label="Relatório pronto para baixar", interactive=False)

                gr.Markdown("### 📥 Importar relatório\nEnvie um relatório .csv para ver o conteúdo em uma tabela.")
                arquivo_imp = gr.File(label="Escolha o arquivo .csv", file_types=[".csv"], type="filepath")
                msg_imp = gr.Markdown()
                tabela_imp = gr.Dataframe(label="Conteúdo do relatório importado", interactive=False)

            with gr.Tab("Perfil", id="aba_perfil") as aba_perfil:
                perfil_box = gr.Markdown()
                btn_sair = gr.Button("Sair")

    # -------- TELA 4: TERMOS DE USO --------
    with gr.Column(visible=False, elem_classes="cartao") as tela_termos:
        gr.Markdown(TERMOS)
        btn_voltar_termos = gr.Button("← Voltar para criar conta", variant="primary")

    # ==========================
    # LIGAÇÕES (o que cada botão faz)
    # ==========================

    telas = [tela_cadastro, tela_login, tela_app, tela_termos]

    # navegação simples
    btn_criar.click(ir_para_cadastro, outputs=telas)
    btn_ja_tenho.click(ir_para_login, outputs=telas)
    btn_ler_termos.click(ir_para_termos, outputs=telas)
    btn_voltar_termos.click(ir_para_cadastro, outputs=telas)

    # a idade aparece sozinha quando a data de nascimento é digitada
    nasc_cad.change(mostrar_idade, inputs=nasc_cad, outputs=idade_cad)

    # criar conta -> entrar
    btn_cadastro.click(
        cadastrar,
        inputs=[nome_cad, nasc_cad, email_cad, senha_cad,
                endereco_cad, bairro_cad, cidade_cad, habilidades_cad, aceite_cad],
        outputs=telas + [msg_cad, email_login]
    )

    # entrar -> app
    btn_login.click(
        login,
        inputs=[email_login, senha_login],
        outputs=telas + [msg_login, usuario, saudacao]
    )

    btn_sair.click(sair, outputs=telas + [usuario, saudacao])

    # oportunidades: os detalhes aparecem sozinhos quando escolhe na lista
    vaga.change(detalhes, inputs=vaga, outputs=detalhes_box)

    # interesse -> atualiza a aba Registro
    btn_interesse.click(interesse, inputs=[vaga, usuario], outputs=registro_box)
    btn_ver_registro.click(ir_para_registro, outputs=abas)
    aba_registro.select(registro, inputs=usuario, outputs=registro_box)

    # publicar -> volta para Oportunidades
    btn_publicar.click(
        publicar,
        inputs=[titulo, valor, local, data, descricao, usuario],
        outputs=[vaga, titulo, valor, local, data, descricao, abas]
    )

    # relatório: gerar para baixar / importar para exibir
    btn_gerar.click(gerar_relatorio, outputs=arquivo_rel)
    arquivo_imp.change(importar_relatorio, inputs=arquivo_imp, outputs=[tabela_imp, msg_imp])

    # perfil: atualiza ao abrir a aba
    aba_perfil.select(perfil, inputs=usuario, outputs=perfil_box)

if __name__ == "__main__":
    app.launch(share="google.colab" in sys.modules)   # no Colab gera o link público
