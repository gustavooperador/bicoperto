"""Banco de dados do BicoPerto (SQLite). Tudo que mexe no banco fica aqui."""

import csv
import hashlib
import hmac
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

PASTA = Path(__file__).parent
CAMINHO = PASTA / "bicoperto.db"
PASTA_RELATORIOS = PASTA / "relatorios"
VERSAO_TERMOS = "1.0"
FUSO = timezone(timedelta(hours=-3))   # horário de Brasília

CABECALHO_RELATORIO = [
    "ID", "Título", "Valor", "Local", "Data",
    "Contratante", "Interesses recebidos", "Publicada em",
]

EXEMPLOS = [
    ("Pintura de parede externa", "R$ 150", "Rua das Flores, 123 - Centro", "Hoje",
     "Maria Ribeiro", "Pintar área externa de aproximadamente 30m²."),
    ("Limpeza de quintal", "R$ 80", "Rua Palmeiras, 45", "Amanhã",
     "João Silva", "Limpeza geral e retirada de folhas."),
    ("Ajudante de mudança", "R$ 200", "Av. Central, 890", "06/06",
     "Carlos Santos", "Auxílio para transporte de móveis."),
]


def agora():
    return datetime.now(FUSO)


@contextmanager
def bd():
    con = sqlite3.connect(CAMINHO)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    try:
        yield con
        con.commit()
    finally:
        con.close()


def criar_banco():
    """Cria as tabelas (se não existirem) e as oportunidades de exemplo."""
    with bd() as con:
        con.executescript((PASTA / "schema.sql").read_text(encoding="utf-8"))
        if con.execute("SELECT COUNT(*) FROM oportunidades").fetchone()[0] == 0:
            con.executemany(
                "INSERT INTO oportunidades (titulo, valor, local, data, contratante, descricao, criado_em) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                [(*e, agora().isoformat(timespec="minutes")) for e in EXEMPLOS],
            )


# ---------- senha ----------

def _hash(senha, sal):
    return hashlib.pbkdf2_hmac("sha256", senha.encode(), sal, 200_000).hex()


def gerar_hash(senha):
    sal = secrets.token_bytes(16)
    return f"{sal.hex()}${_hash(senha, sal)}"


def conferir_senha(senha, guardado):
    sal, esperado = guardado.split("$")
    return hmac.compare_digest(_hash(senha, bytes.fromhex(sal)), esperado)


# ---------- usuários ----------

def criar_usuario(nome, nascimento, email, senha, endereco, bairro, cidade, habilidades):
    """Devolve False se o e-mail já existe. O aceite dos termos é gravado junto."""
    agora_iso = agora().isoformat(timespec="seconds")
    try:
        with bd() as con:
            cur = con.execute(
                "INSERT INTO usuarios (nome, nascimento, email, senha_hash, endereco, bairro, cidade, "
                "aceitou_termos_em, versao_termos, criado_em) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (nome, nascimento, email, gerar_hash(senha), endereco, bairro, cidade,
                 agora_iso, VERSAO_TERMOS, agora_iso),
            )
            con.executemany(
                "INSERT INTO habilidades (usuario_id, habilidade) VALUES (?, ?)",
                [(cur.lastrowid, h) for h in (habilidades or [])],
            )
    except sqlite3.IntegrityError:
        return False
    return True


def obter_usuario(email):
    with bd() as con:
        u = con.execute("SELECT * FROM usuarios WHERE email = ?", (email,)).fetchone()
        if not u:
            return None
        dados = dict(u)
        dados["habilidades"] = [
            r["habilidade"] for r in
            con.execute("SELECT habilidade FROM habilidades WHERE usuario_id = ? ORDER BY habilidade", (u["id"],))
        ]
        return dados


def verificar_login(email, senha):
    u = obter_usuario(email)
    if u and conferir_senha(senha, u["senha_hash"]):
        return u
    return None


# ---------- oportunidades ----------

def listar_titulos():
    with bd() as con:
        return [r["titulo"] for r in con.execute("SELECT titulo FROM oportunidades ORDER BY id")]


def obter_oportunidade(titulo):
    with bd() as con:
        r = con.execute("SELECT * FROM oportunidades WHERE titulo = ?", (titulo,)).fetchone()
        return dict(r) if r else None


def criar_oportunidade(titulo, valor, local, data, descricao, email_dono):
    """Devolve False se já existe uma oportunidade com esse título."""
    dono = obter_usuario(email_dono)
    try:
        with bd() as con:
            con.execute(
                "INSERT INTO oportunidades (titulo, valor, local, data, contratante, descricao, dono_id, criado_em) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (titulo, valor, local, data, dono["nome"], descricao, dono["id"],
                 agora().isoformat(timespec="minutes")),
            )
    except sqlite3.IntegrityError:
        return False
    return True


def contar_publicadas(email):
    with bd() as con:
        return con.execute(
            "SELECT COUNT(*) FROM oportunidades o JOIN usuarios u ON u.id = o.dono_id WHERE u.email = ?",
            (email,),
        ).fetchone()[0]


# ---------- interesses ----------

def registrar_interesse(email, titulo):
    """Devolve False se a pessoa já tinha enviado interesse nessa oportunidade."""
    u, o = obter_usuario(email), obter_oportunidade(titulo)
    try:
        with bd() as con:
            con.execute(
                "INSERT INTO interesses (usuario_id, oportunidade_id, criado_em) VALUES (?, ?, ?)",
                (u["id"], o["id"], agora().isoformat(timespec="minutes")),
            )
    except sqlite3.IntegrityError:
        return False
    return True


def listar_interesses(email):
    """Do mais novo para o mais antigo."""
    with bd() as con:
        linhas = con.execute(
            "SELECT o.titulo, o.valor, o.data, o.local, o.contratante, i.criado_em AS hora "
            "FROM interesses i JOIN oportunidades o ON o.id = i.oportunidade_id "
            "JOIN usuarios u ON u.id = i.usuario_id WHERE u.email = ? ORDER BY i.id DESC",
            (email,),
        )
        return [dict(r) for r in linhas]


# ---------- relatório CSV ----------

def _seguro(texto):
    """Evita que o Excel trate um texto digitado pelo usuário como fórmula."""
    texto = str(texto)
    return "'" + texto if texto[:1] in ("=", "+", "-", "@") else texto


def gerar_relatorio_csv():
    """Cria o arquivo CSV (separador ';', abre direto no Excel em português) e devolve o caminho."""
    PASTA_RELATORIOS.mkdir(exist_ok=True)
    caminho = PASTA_RELATORIOS / f"relatorio_bicoperto_{agora():%Y%m%d_%H%M%S}.csv"
    with bd() as con:
        linhas = con.execute(
            "SELECT o.id, o.titulo, o.valor, o.local, o.data, o.contratante, "
            "COUNT(i.id) AS interesses, o.criado_em "
            "FROM oportunidades o LEFT JOIN interesses i ON i.oportunidade_id = o.id "
            "GROUP BY o.id ORDER BY o.id"
        ).fetchall()
    with open(caminho, "w", newline="", encoding="utf-8-sig") as f:
        escritor = csv.writer(f, delimiter=";")
        escritor.writerow(CABECALHO_RELATORIO)
        for r in linhas:
            escritor.writerow([r["id"], _seguro(r["titulo"]), _seguro(r["valor"]), _seguro(r["local"]),
                               _seguro(r["data"]), _seguro(r["contratante"]), r["interesses"],
                               r["criado_em"][:16].replace("T", " ")])
    return str(caminho)


def ler_relatorio_csv(caminho):
    """Lê um relatório CSV (';' ou ',') e devolve (cabeçalho, linhas)."""
    with open(caminho, newline="", encoding="utf-8-sig") as f:
        texto = f.read()
    separador = ";" if texto.split("\n", 1)[0].count(";") >= texto.split("\n", 1)[0].count(",") else ","
    linhas = list(csv.reader(texto.splitlines(), delimiter=separador))
    if not linhas:
        return [], []
    return linhas[0], linhas[1:]
